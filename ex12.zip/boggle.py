from GameDisplay import *

if __name__ == '__main__':
    gd = GameDisplay()
    gd.start()